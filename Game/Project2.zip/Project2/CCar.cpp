#include "CCar.h"
CCar::CCar()
{
	mX = 15;
	mY = 3;
}
void CCar::Move()//implement generally, still need some arguement to speed up :))
{
	mY += 1;
}
int CCar::getX()
{
	return mX;
}
int CCar::getY()
{
	return mY;
}
int CCar::getType()
{
	return type;
}
