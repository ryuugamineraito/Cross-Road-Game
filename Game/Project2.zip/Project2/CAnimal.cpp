//#include "CAnimal.h"
/*CAnimal::CAnimal(sf::RenderWindow *window)
{
	m_Window = window;
}
void CAnimal::update()
{

}
void CAnimal::draw()
{
	this->m_Window->draw(this->m_sprite);
}
sf::Vector2f CAnimal::getposition()
{
	return this->m_sprite.getPosition();
}*/