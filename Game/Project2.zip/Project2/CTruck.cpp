#include "CTruck.h"
CTruck::CTruck()
{
	mX = 19;
	mY = 66;
}
void CTruck::Move()//implement generally, still need some arguement to speed up :))
{
	mY -= 1;
}
int CTruck::getX()
{
	return mX;
}
int CTruck::getY()
{
	return mY;
}
int CTruck::getType()
{
	return type;
}