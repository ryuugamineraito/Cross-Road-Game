#include <iostream>
#include <Windows.h>
#include "CGame.h"
#include <conio.h>
#include <thread>
using namespace std;
char MOVING;
CGame cg;

bool IS_RUNNING = true;
void SubThread();
void FixConsoleWindow();
void resizeConsole(int width, int height);
void exitGame(thread* t);
void main()
{
	_setmode(_fileno(stdout), _O_U16TEXT);
	int temp;
	FixConsoleWindow();
	resizeConsole(800, 600);
	cg.startGame();
	thread t1(SubThread);
	
	while (1)
	{
		temp = toupper(_getch());
		if (!cg.getPeople().isDead())
		{
			if (temp == 27) {
				//cg.exitGame(t1.native_handle());
				return;

			}
		//	else if (temp == 'P') {
		//		cg.pauseGame(t1.native_handle());

		//	}
			else {
		//		cg.resumeGame((HANDLE)t1.native_handle());
				MOVING = temp; //update move

			}
		}
		/*else
		{
			if (temp == 'Y') cg.startGame();
			else {
				cg.exitGame(t1.native_handle());
				return;

			}
		}*/
		//MOVING = temp;
	}
}
void SubThread()
{
	while (IS_RUNNING) {
		cg.drawMap();
		if (!cg.getPeople().isDead()) //if still alive
		{
			cg.updatePosPeople(MOVING);//update move from main
		}
		MOVING = ' ';// block and wait for user hit key
		cg.updatePosVehicle();//update pos vehicle
		cg.updatePosAnimal(); //update pos animal
		cg.drawGame();
		if (cg.getPeople().isImpact(cg.getVehicle()) ||
			cg.getPeople().isImpact(cg.getAnimal()))
		{
			system("cls");
			wcout << "you lose" << endl;
			return;
		}
		if (cg.getPeople().isFinish()) {
			// when finish
			system("cls");
			wcout << "you win" << endl;

		}
		Sleep(100);
		//cg.updatePosPeople(MOVING);
		/*cg.drawMap();
		cg.updatePosPeople(MOVING);
		MOVING = ' ';
		cg.updatePosVehicle();//update pos vehicle
		cg.updatePosAnimal(); //update pos animal
		cg.drawGame();
		Sleep(0);*/
	}
}
void FixConsoleWindow()
{
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);
	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);
	SetWindowLong(consoleWindow, GWL_STYLE, style);
}
void resizeConsole(int width, int height)
{
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);
	MoveWindow(console, r.left, r.top, width,height, TRUE);
}
void exitGame(thread* t) {
	ClearScreen();
	IS_RUNNING = false;
	t->join();
}
