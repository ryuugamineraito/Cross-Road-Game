﻿#ifndef _CGAME_H_
#define _CGAME_H_
#include <iostream>
#include <Windows.h>
#include <vector>
#include "CPeople.h"

#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <SFML/Graphics.hpp>
using namespace std;

class CGame
{
	sf::Clock m_clock;
	sf::Time m_time;
	sf::Time m_time1;
	sf::Clock m_clock1;
	wchar_t map[50][70];
	vector<CVehicle*> vehicles;
	vector<CAnimal*> animals;
	CPeople cn;
public:
	CGame(); //Chuẩn bị dữ liệu cho tất cả các đối tượng
	void drawGame(); //Thực hiện vẽ trò chơi ra màn hình sau khi có dữ liệu
	void drawPeople();
	void drawMap();
	void drawTruck(CVehicle* obj);
	void drawCar(CVehicle *obj);
	void drawBird(CAnimal*obj);
	void drawDinosaur(CAnimal*obj);
	//~CGame(); // Hủy tài nguyên đã cấp phát
	CPeople getPeople();
	vector<CVehicle*> getVehicle();
	vector<CAnimal*> getAnimal(); 
	//void resetGame(); // Thực hiện thiết lập lại toàn bộ dữ liệu như lúc đầu
	void exitGame(HANDLE); // Thực hiện thoát Thread
	void startGame(); // Thực hiện bắt đầu vào trò chơi
	//void loadGame(istream); // Thực hiện tải lại trò chơi đã lưu
	//void saveGame(istream); // Thực hiện lưu lại dữ liệu trò chơi
	//void pauseGame(HANDLE); // Tạm dừng Thread
	//void resumeGame(HANDLE); //Quay lai Thread
	void updatePosPeople(const char& key); //Thực hiện điều khiển di chuyển của CPEOPLE
	void updatePosVehicle(); //Thực hiện cho CTRUCK & CCAR di chuyển
	void updatePosAnimal();//Thực hiện cho CDINAUSOR & CBIRD di chuyển


};
void textcolor(int x);
void GotoXY(int x, int y);
void ClearScreen();
#endif // !_CGAME_H_

