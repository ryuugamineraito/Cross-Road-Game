#include "CDinosaur.h"
CDinosaur::CDinosaur()
{
	mX = 11;
	mY = 66;
}
void CDinosaur::Move()//implement generally, still need some arguement to speed up :))
{
	mY -= 1;
}
int CDinosaur::getX()
{
	return mX;
}
int CDinosaur::getY()
{
	return mY;
}
int CDinosaur::getType()
{
	return type;
}