#include "CBird.h"
CBird::CBird()
{
	mX = 6;
	mY = 3;
}
void CBird::Move()//implement generally, still need some arguement to speed up :))
{
	mY += 1;
}
int CBird::getX()
{
	return mX;
}
int CBird::getY()
{
	return mY;
}
int CBird::getType()
{
	return type;
}