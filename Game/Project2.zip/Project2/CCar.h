#ifndef _CCAR_H_
#define _CCAR_H_
#include "CTruck.h"
class CCar :public CVehicle
{
	int type = 2;
public:
	int getType();
	CCar();
	void Move();
	int getX();
	int getY();
};
#endif // !_CCAR_H_

