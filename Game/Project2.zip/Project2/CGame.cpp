#include "CGame.h"

void textcolor(int x)
{
	HANDLE color;
	color = GetStdHandle

	(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(color, x);
}
void GotoXY(int x, int y) {
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void ClearScreen()
{
	HANDLE hOut;
	COORD Position;
	hOut = GetStdHandle

	(STD_OUTPUT_HANDLE);
	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}
//above is for graphic
CGame::CGame()
{

}
CPeople CGame::getPeople()
{
	return cn;
}
vector<CVehicle*> CGame::getVehicle()
{
	return vehicles;
}
vector<CAnimal*> CGame::getAnimal()
{
	return animals;
}
//place here tempolarily
void CGame::drawMap()
{
	for (int i = 0; i < 24; i++)
	{

		for (int j = 0; j < 70; j++)
		{

			if (i+1<=20&&(i+1) % 4 == 0)
			{
				map[i][j] = '_';
			}
			else
				map[i][j] = ' ';
		}
	}
	
	
}
void CGame::drawGame()
{
	ClearScreen();
		wcout<<"\n\n\n";
		for (int i = 0; i < 24; i++)
		{
			wcout <<"\t\t";
			for (int j = 0; j < 70; j++)
			{
				
				if (map[i][j]==9604 || map[i][j] == '_'||map[i][j]==708||map[i][j]==9600||map[i][j]== 9608)
				{
					textcolor(240);
					wcout << map[i][j];
					textcolor(7);
				}
				else
				{
					textcolor(250);
					wcout << map[i][j];
					textcolor(7);
				}
			}
			wcout << endl;
		}
}
void CGame::startGame()
{
	ClearScreen();
	wcout << "Welcome to my game" << endl;
	Sleep(2000);
	system("cls");
}
void CGame::updatePosPeople(const char& key)
{
	cn.Up(key);
	cn.Down(key);
	cn.Left(key);
	cn.Right(key);
	drawPeople();
}
void CGame::drawPeople()
{
	int x = cn.getX();
	int y = cn.getY();
	map[x][y]=708; // Body,center
	map[x - 1][y] =9604; // Head
	
}
void CGame::updatePosVehicle()
{
	if (this->vehicles.size() > 0)
	{
		for (auto iter = vehicles.begin(); iter != vehicles.end(); ++iter)
		{
			(*iter)->Move();
			if ((*iter)->getType() == 1)
				drawTruck((*iter));
			else
				drawCar((*iter));
		}
		//This also will be configured later
		if (this->vehicles[0]->getY() <= 3 || this->vehicles[0]->getY() > 66)
			this->vehicles.erase(this->vehicles.begin());
	}
	CVehicle*p;
	this->m_time = this->m_clock.getElapsedTime();

	if (this->m_time.asSeconds() > 2)// should be considered about random further
	{
		p = new CTruck();
		vehicles.push_back(p);
		p = new CCar();
		vehicles.push_back(p);
		this->m_clock.restart();

		//	x = std::rand() % 500 + 201;
	}
}
void CGame::updatePosAnimal()
{
	if (this->animals.size() > 0)
	{
		for (auto iter = animals.begin(); iter != animals.end(); ++iter)
		{
			(*iter)->Move();
			if ((*iter)->getType() == 1)
				drawDinosaur((*iter));
			else
				drawBird((*iter));
		}
		//This also will be configured later
		if (this->animals[0]->getY() <= 3 || this->animals[0]->getY() > 66)
			this->animals.erase(this->animals.begin());
	}
	CAnimal*p;
	this->m_time1 = this->m_clock1.getElapsedTime();

	if (this->m_time1.asSeconds() > 2)// should be considered about random further
	{
		p = new CDinosaur();
		animals.push_back(p);
		p = new CBird();
		animals.push_back(p);
		this->m_clock1.restart();

		//	x = std::rand() % 500 + 201;
	}
}
void CGame::drawTruck(CVehicle* obj)
{
	int x = obj->getX();
	int y = obj->getY();
	map[x][y] = 9600; // center
	map[x][y + 1] = 9600;
	map[x][y - 1] = 9600;
	map[x - 1][y] = 9604;
	map[x - 1][y + 1] = 9604;
}
void CGame::drawCar(CVehicle* obj)
{
	int x = obj->getX();
	int y = obj->getY();
	map[x][y] = 9600; // center
	map[x][y - 1] = 9600;
	map[x][y + 1] = 9600;
	map[x][y + 2] = 9600;
	map[x - 1][y] = 9604;
	map[x - 1][y + 1] = 9604;
}
void CGame::drawBird(CAnimal*obj)
{
	int x = obj->getX();
	int y = obj->getY();
	map[x][y] = 9600; // head,center
	map[x - 1][y - 1] = 9604; // wing1
	map[x - 1][y + 1] = 9604;//wing2
}

void CGame::drawDinosaur(CAnimal*obj)
{
	int x = obj->getX();
	int y = obj->getY();
	map[x][y] = 9600; // center
	map[x][y - 1] = 9600;
	map[x - 1][y] = 9604;
	map[x - 1][y + 1] = 9608;
}
