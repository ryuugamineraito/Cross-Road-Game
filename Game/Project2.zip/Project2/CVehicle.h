#ifndef _CVEHICLE_H_
#define _CVHICLE_H_
#include <iostream>
#include <Windows.h>
#include <string>
#include <cstdlib>
#include <time.h>
class CVehicle
{
protected:
	int mX,mY;

public:
	//CVehicle();
	virtual void Move()=0;
	virtual int getX()=0;
	virtual int getY() = 0;
	virtual int getType() = 0;
};
#endif // !_CVEHICLE_H_

